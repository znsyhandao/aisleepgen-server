// pages/index/index.js — Sleep Intelligence Dashboard
const api = require('../../utils/api');
const app = getApp();

Page({
  data: {
    // Dashboard data
    greeting: '晚上好',
    dateStr: '',
    hasData: false,
    lastScore: 0,
    duration: '',
    quality: '',
    bedtime: '',
    awakeTimes: 0,
    deepPct: 0,
    lightPct: 0,
    remPct: 0,
    oneLiner: '',
    weekAvg: 0,
    // Score ring
    scoreColor: '#666',
    scoreGradColor: '#666',
    scoreDeg: 0,
    // Prediction
    prediction: null,
    predictedScore: '--',
    predConfidence: '',
    predTrendText: '',
    predTrendClass: '',
    predConcern: '',
    // Comparison
    vsText: '',
    vsColor: '#888',
    // Coach
    coachSuggestion: '',
    // Loading
    loading: true,
    // Sleep story
    sleepStory: '',
    // Band data
    bandData: null,
    // Audio analysis
    audioAnalysis: null,
  },

  onLoad() {
    this.loadDashboard();
  },

  onShow() {
    this.loadDashboard();
  },

  loadDashboard() {
    // Date
    var now = new Date();
    var month = now.getMonth() + 1;
    var day = now.getDate();
    var dayNames = ['日', '一', '二', '三', '四', '五', '六'];
    var dayName = dayNames[now.getDay()];
    var dateStr = '周' + dayName + ' ' + month + '/' + day;

    this.setData({ dateStr: dateStr });

    var openid = wx.getStorageSync('openid') || 'default';

    api.post('/api/dashboard', { openid: openid })
      .then(res => {
        var dash = res.dashboard || {};
        if (!dash.has_data) {
          this.setData({ hasData: false, loading: false });
          return;
        }

        // Score ring color
        var scoreGrad = '#666';
        var scoreColor = '#888';
        var scoreDeg = (dash.last_score / 100) * 360;
        if (dash.last_score >= 80) {
          scoreColor = '#27AE60';
          scoreGrad = '#27AE60, #2ECC71';
        } else if (dash.last_score >= 65) {
          scoreColor = '#4A90E2';
          scoreGrad = '#4A90E2, #6FCF97';
        } else if (dash.last_score >= 50) {
          scoreColor = '#F2994A';
          scoreGrad = '#F2994A, #EB5757';
        } else {
          scoreColor = '#EB5757';
          scoreGrad = '#EB5757';
        }

        // Prediction
        var pred = dash.prediction || {};
        var predictedScore = pred.predicted_score || '--';
        var predConfidence = '';
        if (pred.confidence === 'high') predConfidence = '高';
        else if (pred.confidence === 'medium') predConfidence = '中';
        else predConfidence = '低';

        var predTrendText = '';
        var predTrendClass = '';
        if (pred.direction === 'better') {
          predTrendText = '↗ 上升趋势';
          predTrendClass = 'trend-up';
        } else if (pred.direction === 'worse') {
          predTrendText = '↘ 需要关注';
          predTrendClass = 'trend-down';
        } else {
          predTrendText = '→ 稳定';
          predTrendClass = 'trend-stable';
        }

        var predConcern = '';
        if (pred.key_concern === 'latency') predConcern = '入睡困难';
        else if (pred.key_concern === 'awake') predConcern = '夜间易醒';
        else if (pred.key_concern === 'duration') predConcern = '睡眠不足';
        else predConcern = '';

        // Week comparison
        var vsText = '';
        var vsColor = '#888';
        if (dash.week_avg > 0 && dash.last_score > 0) {
          var diff = dash.last_score - dash.week_avg;
          if (diff > 0) {
            vsText = '高于周均 ' + diff.toFixed(1) + ' 分';
            vsColor = '#27AE60';
          } else if (diff < 0) {
            vsText = '低于周均 ' + Math.abs(diff).toFixed(1) + ' 分';
            vsColor = '#EB5757';
          } else {
            vsText = '与周均持平';
            vsColor = '#888';
          }
        }

        // Sleep story from narrative engine
        var sleepStory = dash.sleep_story || '';
        // Band data
        var bandData = dash.band_data ? {
          heartRate: dash.band_data.heart_rate || dash.band_data.heartRate,
          spo2: dash.band_data.spo2 || dash.band_data.blood_oxygen,
          movement: dash.band_data.movement || dash.band_data.body_movement,
          source: dash.band_data.source || dash.band_data.device,
        } : null;
        // Audio analysis
        var audioAnalysis = dash.audio_analysis ? {
          snoreLevel: dash.audio_analysis.snore_level || dash.audio_analysis.snore,
          movementLevel: dash.audio_analysis.movement_level || dash.audio_analysis.movement,
          stability: dash.audio_analysis.stability || dash.audio_analysis.stability_level,
        } : null;

        this.setData({
          hasData: true,
          loading: false,
          sleepStory: sleepStory,
          bandData: bandData,
          audioAnalysis: audioAnalysis,
          greeting: dash.greeting || '晚上好',
          lastScore: dash.last_score || 0,
          duration: dash.duration || '',
          quality: dash.quality || '',
          bedtime: dash.bedtime || '--',
          awakeTimes: dash.awake_times || 0,
          deepPct: dash.deep_pct || 0,
          lightPct: dash.light_pct || 0,
          remPct: dash.rem_pct || 0,
          oneLiner: dash.one_liner || '',
          weekAvg: dash.week_avg || 0,
          scoreColor: scoreColor,
          scoreGradColor: scoreGrad,
          scoreDeg: scoreDeg,
          prediction: dash.prediction ? true : false,
          predictedScore: predictedScore,
          predConfidence: predConfidence,
          predTrendText: predTrendText,
          predTrendClass: predTrendClass,
          predConcern: predConcern,
          vsText: vsText,
          vsColor: vsColor,
        });
      })
      .catch(err => {
        console.warn('[Dashboard] Load error:', err);
        this.setData({ loading: false });
      });
  },

  goToReport() {
    wx.navigateTo({ url: '/pages/report/report' });
  },

  goToPage(e) {
    var page = e.currentTarget.dataset.page;
    wx.navigateTo({ url: '/pages/' + page + '/' + page });
  },

  // ===== v7.2 新功能: 加载图表数据 =====
  loadChartData: function() {
    var self = this;
    api.getChartData().then(function(res) {
      if (res && res.success && res.chart) {
        var chart = res.chart;
        var trend = chart.trend_line || {};
        var pie = chart.stage_pie || {};
        var radar = chart.radar || {};
        var heat = chart.heatmap || {};
        var weekly = chart.weekly_compare || {};

        self.setData({
          chartTrendLabels: trend.labels || [],
          chartTrendValues: trend.values || [],
          chartTrendAvg: trend.avg || 0,
          chartTrendDirection: trend.trend || 'flat',
          chartPieData: pie.data || [],
          chartRadarData: radar.data || [],
          chartHeatData: heat.data || [],
          chartWeeklyChange: weekly.change || 0,
          chartWeeklyThis: weekly.this_week_avg || 0,
          chartWeeklyLast: weekly.last_week_avg || 0,
          hasChartData: true,
        });
      }
    }).catch(function(err) {
      console.warn('[Chart] Load error:', err);
    });
  },

  // ===== v7.2 新功能: 加载睡前预判 =====
  loadSiegePredict: function() {
    var self = this;
    api.getSiegePredict().then(function(res) {
      if (res && res.success && res.prediction) {
        var pred = res.prediction;
        self.setData({
          siegeAlert: pred.alert_level || '',
          siegeScore: pred.score || 0,
          siegeConfidence: pred.confidence || 0,
          siegeConfidencePct: Math.round((pred.confidence || 0) * 100),
          siegInterventions: pred.interventions || [],
          siegeRiskFactors: (pred.risk_factors || []).slice(0, 3),
          siegeReportText: res.report_text || '',
          hasSiegeData: true,
        });
      }
    }).catch(function(err) {
      console.warn('[Siege] Load error:', err);
    });
  },

  // ===== v7.2 新功能: 加载诊断书 =====
  loadDiagnosis: function() {
    var self = this;
    api.getSiegeDiagnosis().then(function(res) {
      if (res && res.success && res.diagnosis) {
        var diag = res.diagnosis;
        self.setData({
          diagnosisGrade: diag.grade || '',
          diagnosisGradeLabel: diag.grade_label || '',
          diagnosisScore: diag.composite_score || 0,
          diagnosisAdvice: diag.advice || [],
          diagnosisMetrics: diag.metrics || {},
          hasDiagnosisData: true,
        });
      }
    }).catch(function(err) {
      console.warn('[Diagnosis] Load error:', err);
    });
  },

  // ===== v7.2 新功能: 加载自动日记 =====
  loadAutoDiary: function() {
    var self = this;
    api.getAutoDiary().then(function(res) {
      if (res && res.success && res.diary) {
        self.setData({
          diaryScore: res.diary.composite_score || 0,
          diaryText: res.diary.diary_text || '',
          diaryShort: res.short_text || '',
          diaryCompleteness: res.diary.completeness || 0,
          hasDiaryData: true,
        });
      }
    }).catch(function(err) {
      console.warn('[Diary] Load error:', err);
    });
  },

  // ===== v7.2 新功能: 加载三层记忆 =====
  loadMemoryRecall: function() {
    var self = this;
    api.getMemoryRecall().then(function(res) {
      if (res && res.success && res.recall_text) {
        self.setData({
          memoryRecallText: res.recall_text,
          memoryRecallLength: res.length || 0,
          hasMemoryData: true,
        });
      }
    }).catch(function(err) {
      console.warn('[Memory] Load error:', err);
    });
  },

  // 增强版onLoad：加载所有数据
  onLoad: function() {
    this.loadDashboard();
    this.loadChartData();
    this.loadSiegePredict();
    this.loadDiagnosis();
    this.loadAutoDiary();
    this.loadMemoryRecall();
  },
});
