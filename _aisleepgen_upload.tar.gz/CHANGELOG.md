# Changelog

## v7.1.0 - 小程序UI全面升级

### 深色主题一致性
- 所有页面统一背景 `#0f0f23`（修复原 `#0f3460` 残留）
- tabBar 背景同步修改为深色
- app.wxss 新增磨砂玻璃工具类（`.glass`）、骨架屏动画

### 加载态优化
- 首页 (index) 增加骨架屏 `<skeleton>` 组件（shimmer 动画）
- 所有数据请求页面保留加载状态逻辑

### 新功能卡片 - 首页
- **睡眠故事卡片**：基于 narrative_engine 输出的个性化睡眠故事📖
- **手环数据卡片**：心率、血氧、体动次数展示⌚
- **音频分析卡片**：鼾声、体动、稳定性分析🎤

### 决策透明性 - Chat页
- AI 回复新增「决策解释」气泡，展示推荐理由、指标、置信度🧠

### Profile 增强
- **每日皮肤对比**卡片：面部特征指标可视化🧏
- 睡眠与皮肤关联分析可从首页直连

### A/B实验管理
- 新增 `pages/abtest/` 管理页面，支持查看运行中/已完成实验🧪
- 注册到 app.json 路由

### 依赖
- 不改动后端逻辑，纯前端 WXML/WXSS/JS 增强

## v7.0.0 - 皮肤-睡眠关联分析

### New: scripts/skin_sleep_analysis_v7.py
- 面部皮肤特征与睡眠评分Pearson相关性分析
- 按性别（女性/男性）分别分析
- 随机森林回归（GridSearch调参 + LOOCV）
- 生成4项分析产物：
  - `correlation_report_v7.txt` — 中文相关系数报告
  - `skin_sleep_trend_v7_*.png` — 双Y轴趋势图
  - `rf_feature_importance_v7_*.png` — 特征重要性图
  - `rf_results_v7.json` — 模型评估指标JSON

### Findings (女性/主人自测数据)
- 最强相关特征：roi_jaw_L (r=-0.359), roi_grad_forehead_jaw (r=0.325)
- GLCM纹理特征与睡眠负相关：glcm_energy (r=-0.423), glcm_homogeneity (r=-0.333)
- 男性数据仅1天，无法独立建模

### 数据修复
- 修复CSV日期20250501→20260501年份不匹配问题
- 补充无文本评分日期的中位数值

## v6.5.0 - Proactive Manager（主动健康管理）

### New: proactive_manager.py (~23KB)

- **ProactiveManager 主动健康管理器**: 系统能在用户不主动说话时主动发起互动
  - 5种触发条件：
    - predictive_push: 预测评分<45 + 19-21点 — 推送干预方案
    - trend_warning: 连续3天下降速度<-3分/天 — 推送趋势预警
    - milestone: 连续7天评分>70 — 推送里程碑庆祝
    - relapse_detection: 评分从>70跌到<50且跌幅>30分 — 推送安抚+重新评估
    - no_interaction_reminder: 超过72h无互动 — 友好提醒
  - Cooldown机制防止短时间重复推送（24h/48h/7天不等）
  - 每日推送上限：默认3条，连续2次负面反馈后降到1条
  - 集成到scheduler_daemon.py：在每次调度周期中评估触发条件
  - 集成到safe_guards.py：check_proactive_rate() / record_proactive_feedback()

### Routes (2 new API endpoints)
- `POST /api/proactive/status` — 查询当前待触发动作
- `POST /api/proactive/dismiss` — 手动取消某个触发

### Integration: scheduler_daemon.py
- 在调度主循环中新增主动健康管理扫描步骤
- 检查每日推送上限，触发后写入推送队列

### Integration: safeguards.py
- 新增主动推送频率限制：MAX_PROACTIVE_PUSHES_PER_DAY (3)
- check_proactive_rate() 每日计数器
- record_proactive_feedback() 负面反馈追踪
- get_proactive_push_count() 获取今日推送数

### Tests
- 7个自测场景全部通过
- predictive_push/trend_warning/relapse_detection/no_interaction_reminder 触发条件
- cooldown期内不重复 / 每日上限3条 / 负面反馈降低频率

## v6.4.0 - Decision Explainer（决策解释器）

### New: decision_explainer.py (~20KB)

- **DecisionExplainer 决策解释器**: 为每个决策生成自然语言解释，让决策透明、可理解
  - `DecisionExplainer` 类: explain(), explain_chain(), get_explanation_for_action(), get_last_explanation()
  - 解释框架：summary（一句话概括）、trigger（触发原因）、evidence（多维度证据）、
    expected_impact（预期影响）、alternatives（其他选项对比）、confidence（确定程度）
  - 下降趋势→push决策 → 解释包含"恶化"字眼
  - 平稳→skip决策 → 解释包含"观察/不干预"语义
  - 决策链各层不一致 → 解释体现不同意见（RL vs POMDP vs WM vs 时序）
  - 集成到chat_prompt_builder.py：build_decision_context() 在pomdp_context后追加 [决策解释: ...]
  - 集成到dp_router.py：handle_chat中注入决策解释到body_context；
    新增 POST /api/explain/last 路由
  - 集成到agent_gateway.py：新增explain_decision能力

### Routes (1 new API endpoint)
- `POST /api/explain/last` — 获取最近一次决策解释

## v6.3.0 - Narrative Engine（睡眠故事生成器）

### New: narrative_engine.py (~27KB)

- **Narrative Engine 叙事引擎**: 把多层数据融合成有叙事的自然语言文本，不是模板拼接
  - `NarrativeEngine` 类: generate_story(), generate_weekly_summary(), generate_comparison()
  - 4个叙述模块：现状（What）、原因（Why）、预测（What's next）、建议（What to do）
  - 模块1从POMDP信念提取评分、置信度、状态判断；从WM提取短期趋势；从时序签名提取速度/加速度
  - 模块2从意图引擎提取症状报告；从emotion_monitor提取情绪趋势；从circadian_phase_model提取作息规律性
  - 模块3从behavior_predictor提取今晚预测+置信度；从时序外推趋势
  - 模块4从sleep_coach提取推荐干预方案+理由；从AEO权重提取权重解释
  - 上下文适配：chat简短1-2句版 / analyze完整4段版 / weekly完整版
  - 数据不足自动降级为"数据不足，再聊几次我就能给你分析了"
  - 下降趋势体现"恶化"语义，上升趋势体现"改善"语义
  - 集成到chat_prompt_builder.py：build_narrative_context() 在pomdp_context后追加
  - 集成到dp_router.py：handle_chat中注入睡眠故事到body_context
  - 集成到agent_gateway.py：新增generate_story能力

### Routes (2 new API endpoints)
- `POST /api/narrative/story` — 手动查用户睡眠故事
- `POST /api/narrative/weekly` — 手动查周报

### Integration: dp_router.py
- handle_chat 中在intent_context后注入叙事故事 [睡眠故事: ...]
- 新增 narrative API endpoints

### Integration: agent_gateway.py
- 新增 CAPABILITY_SCHEMAS 条目 "generate_story"
- dispatch_map 新增 generate_story -> _do_generate_story
- 实现 _do_generate_story 方法

### Tests
- 5个自测场景全部通过
- 有数据用户→完整4模块；空用户→数据不足简短版；下降/上升趋势→语义正确；注入格式正确



- **Intent Engine 意图引擎**: 让用户的每一句话不仅是POMDP信念更新的观测信号，还直接触发具体子流程
  - `IntentEngine` 类: classify(text, context) -> IntentResult, register_intent(), list_intents()
  - 15种预定义意图: report_insomnia, report_early_waking, report_poor_quality, report_good_sleep,
    request_analysis, request_advice, request_suggestion, positive_feedback, negative_feedback,
    repeat_intervention, express_anxiety, express_sadness, greeting, chitchat
  - 基于关键词+正则模式匹配（轻量级，不依赖LLM）
  - 优先级排序: 高优先级意图优先匹配（90-0）
  - 多意图检测: 一条消息可同时匹配多个意图（主+次）
  - Handler注册机制: 12个处理函数，覆盖干预建议/信念更新/RL奖励/情绪记录等
  - Fallback机制: 无匹配时降级到chitchat
  - 置信度计算: 基于匹配位置（开头>中间）+ 模式长度
  - 上下文感知: 短反馈词("不错")在非睡眠语境下降权
  - IntentResult 结构: primary_intent, confidence, matched_pattern, secondary_intents, handlers, handler_results
  - 上下文注入: to_context_str() 生成LLM可读的 [意图识别:] 格式文本
  - 单例模式: get_intent_engine() 懒加载初始化
  - 14个自测场景全部通过

### Routes (2 new API endpoints)
- `POST /api/intent/classify` — 手动测试意图分类
- `GET /api/intent/list` — 查看已注册的意图规则

### Integration: dp_router.py
- handle_chat 中 intent_engine.classify() 在用户消息到LLM之前插入
- handler执行结果注入到 body_context -> LLM prompt [意图识别: ...] 块
- 不绕过LLM: handler结果作为额外上下文，LLM仍负责最终回复生成
- 所有handler非阻塞运行（异常不中断主流程）

### 测试标准（全部通过）
1. "失眠" -> report_insomnia, trigger_intervention触发
2. "睡得好" -> report_good_sleep, update_pomdp_belief+update_rl_reward
3. "帮我看看" -> request_analysis, trigger_analysis
4. "没用" -> negative_feedback, update_rl_reward+trigger_alternative
5. "焦虑" -> express_anxiety, anxiety_intervention
6. "再做一次" -> repeat_intervention
7. "你好" -> greeting, greeting_response
8. 复杂文本 -> 主=insomnia 次=anxiety
9. 无匹配文本 -> chitchat
10. handler执行结果正确注入LLM上下文

## v6.1.0 - AEO (Agent Engine Optimization)


### New: weight_optimizer.py (~16KB)

- **AEO 决策权重动态优化系统**: 决策因素的权重不再硬编码，由A/B实验数据+集群特征动态决定
  - `WeightOptimizer` 类: get_weights, set_base_weights, record_outcome, optimize, get_cluster_weights
  - 权重结构: rl(0.35), pomdp(0.35), wm(0.15), temporal(0.15)
  - 全局基准权重: 通过 optimize() 定期调优，每次±0.02微调
  - 集群特异权重: 每个用户集群独立维护一套权重，独立调优
  - 集群样本<10人时不独立调整，用全局基准
  - 上下文微调: 高不确定→temporal+5%, 低不确定→rl+5%, 新用户→wm+10%, 恶化中→pomdp+10%
  - optimize()算法: 按权重分组分析outcome，当前值效果更好则+0.02，否则-0.02
  - 存储: data/weight_history/ 目录 (base_weights.json, cluster_weights.json, outcome_log.json)
  - 单例模式: get_weight_optimizer() 懒加载初始化

### Routes (3 new API endpoints)
- `POST /api/weights/status` — 当前权重配置
- `POST /api/weights/optimize` — 手动触发优化
- `POST /api/weights/reset` — 重置权重到默认值

### Integration: conscious_decider.py
- 替换硬编码RL权重0.35为AEO动态权重
- 构建决策上下文(高/低不确定, 恶化状态)传递给WeightOptimizer
- 每次决策完成后自动记录使用的权重和outcome

### Integration: population_manager.py
- periodic_maintenance()中自动刷新WeightOptimizer集群权重
- 新集群创建/重聚类时自动初始化集群特异权重

### Integration: ab_framework.py
- 新增 create_weight_experiment(): 创建A/B实验比较不同权重配比
- AEO权重优化结果可自动注入A/B实验配置

### Integration: dp_router.py
- /api/intervention-complete 记录AEO权重outcome
- A/B实验outcome自动关联AEO权重信息

### Integration: dynamic_safeguards.py
- _check_cluster_weights(): 检查集群权重是否持续产生差outcome
- auto_rollback_cluster_weights(): 回滚差集群权重到全局基准
- 安全摘要中显示需要回滚的集群

### Tests
- 10 self-test 场景全部通过 (weight_optimizer.py)
- 覆盖: 初始权重, 高/低不确定, 新用户, 恶化状态, optimize归一化, 变化幅度, 集群独立, 集群样本不足, set/reset

## v6.0.0 - Agent Gateway（语义协议层）

### New: agent_gateway.py (~20KB)

- **Agent Gateway**: 语义协议层，让外部AI Agent能直接调用系统全部核心能力
  - `AgentGateway` 纯Python类，不依赖Flask，支持直接import或REST API包装
  - 11个注册能力（capability）：query_belief, query_prediction, query_intervention, query_temporal_state, query_experiment_results, report_observation, report_intervention_outcome, request_decision, create_ab_experiment, query_system_status, query_user_profile
  - 能力注册表（CAPABILITY_SCHEMAS）：每个能力带description, params schema, returns schema
  - AgentRequest/AgentResponse 协议格式：version, capability, params, context → success, data, error, meta
  - JSON Schema 支持：get_capability_schema() 返回标准JSON Schema
  - 参数校验：基于注册表自动校验必填参数、类型、枚举值
  - 错误处理：未知能力、缺少参数、运行时异常 → 统一格式的错误响应
  - 追踪ID：自动生成或使用外部传入trace_id
  - 性能计时：每个能力调用自动记录duration_ms
  - 版本化协议：AgentRequest/AgentResponse 带 version 字段，支持schema升级
  - 单例模式：get_gateway() 懒加载初始化
  - 模块懒加载：能力函数内按需加载对应模块（pomdp_learner, working_memory等）

### 能力实现详情

- **query_belief**: → pomdp_learner.get_engine().get_belief() + working_memory.temporal_signature()
- **query_prediction**: → behavior_predictor.BehaviorPredictor (predict_tonight + predict_trend + anomaly_score) + fallback prediction_engine
- **query_intervention**: → online_rl.get_online_rl().act() + pomdp_learner.decide() + sleep_coach.get_daily_suggestion() + conscious_decider
- **query_temporal_state**: → working_memory.temporal_signature() + state_context()
- **query_experiment_results**: → ab_framework.list_experiments() + load_winner_config()
- **report_observation**: → pomdp_learner.observe() / observe_survey() based on observation_type
- **report_intervention_outcome**: → experiment_log.record_designed() + online_rl.update() + ab_framework.record_outcome()
- **request_decision**: 完整决策链路（RL→POMDP→Conscious Decider→多数投票→winner→intervention）
- **create_ab_experiment**: → ab_framework.create_experiment() + start_experiment()
- **query_system_status**: 聚合version, total_users, active_experiments, total_clusters, pomdp_params, rl_params, safeguard_status
- **query_user_profile**: 聚合summary, cluster_id, total_interactions, recent_trend, rl_policy

### Router 集成（dp_router.py）

- 3条新Agent Gateway路由：
  - `POST /api/agent` — 接受AgentRequest JSON，返回AgentResponse JSON
  - `GET /api/agent/capabilities` — 返回能力清单（外部Agent发现用）
  - `POST /api/agent/schema` — 获取指定能力的JSON Schema

### Technical

- 51 Python files（48→51, +agent_gateway.py, +_test_gateway.py, +_test_router.py）
- 0文件被删除，0现有功能被修改
- 全部现有 behavior_auditor 场景仍通过（46/46）
- 新增15个集成测试场景（agent_gateway完整覆盖）
- Version: 5.1.0 → 6.0.0
- **A/B Testing Framework**: Real-user online split-testing module
  - `ABFramework` class with full experiment lifecycle (created → running → evaluating → completed)
  - Consistent user assignment via md5-based hashing (same user always same arm)
  - Configurable split ratio (default 50/50), supports arbitrary parameter dicts
  - Statistical significance test (independent t-test, p < 0.05, scipy)
  - Minimum sample guard (30/arm) and minimum runtime guard (24h) to prevent false positives
  - 7-day timeout: auto-closes with tie if not significant after 7 days
  - Secondary metrics: intervention effectiveness, retention, negative feedback rate, interaction frequency
  - Auto-promotion: winner config written to `data/ab_experiments/winner_config.json`
  - Config history: all previous winner configs archived for one-click rollback
  - Canary experiment support (5% vs 95%) with dynamic_safeguards integration

### API Routes (6 new, registered in dp_router.py)
  - `POST /api/ab/create` — create A/B experiment
  - `POST /api/ab/evaluate` — evaluate experiment results
  - `POST /api/ab/list` — list all experiments with status filter
  - `POST /api/ab/stop` — stop experiment and optionally promote winner
  - `POST /api/ab/canary-create` — create canary experiment
  - `POST /api/ab/winner-config` — view current winner config and history
  - `POST /api/ab/rollback` — rollback to historical winner version

### Integration
- **conscious_decider.py**: AB experiment config overrides decision parameters (rl_weight, pomdp_weight, push_threshold, epsilon_decay_steps, forget_factor)
  - AB outcome recording after each decision (score, action taken, confidence)
  - RL voting weight overridden by experiment config
- **online_rl.py**: AB experiment config overrides RL hyperparameters (alpha, gamma, epsilon, epsilon_decay_steps)
  - `set_ab_config()/clear_ab_config()` per-user methods
  - `_get_effective_params()` merged base + AB override values
- **meta_learner.py**: Running AB experiments pause global adjustments (to avoid confounding)
  - Canary experiments still allow adjustments (isolated impact)
- **dp_router.py**: 7 new AB management API routes registered

### Technical
- 48 → 49 Python files
- Storage: `data/ab_experiments/experiments.json`, `{id}_outcomes.json`, `winner_config.json`, `config_history/`
- Thread-safe with threading.Lock on all mutations
- Self-test: 14 tests covering all design criteria (all PASS)
- Version: 5.0.0 → 5.1.0

## v5.0.0 - Online RL (Active Sampling)

### New
- **online_rl.py**: Online Reinforcement Learning decision module (~15KB)
  - State space: 4D → 144 discrete states (score bin × trend × uncertainty × last effect)
  - Action space: 6 actions (ask, probe, push, delay_push, skip, companion)
  - Double Q-learning: two alternating Q tables to reduce overestimation bias
  - Context-aware ε-greedy exploration: high-entropy(+0.1), new user(0.4), counter effect(0.35)
  - ε decay: 0.2 → 0.05 over time (DECAY_RATE=0.9995)
  - Per-user persistence: data/online_rl/{openid}_q.json + {openid}_history.json
  - extract_reward_from_outcome(): automatic reward extraction from user feedback/score/silence
  - Action penalties: ask(-0.1), push(-0.2) to avoid over-questioning/over-pushing

- **conscious_decider.py**: RL decision layer (35% voting weight)
  - RL decision inserted as layer 0 (before POMDP, before weighted vote)
  - RL action → CD action mapping (ask→probe, companion→in_chat, etc.)
  - RL action prepended to decision reason string

- **chat_prompt_builder.py**: RL strategy info injected into LLM prompt
  - [RL策略: 当前最优=ask(Q=1.27), 次优=probe(Q=0.89), 探索率=0.22]
  - Injected at end of pomdp_context after POMDP belief details

- **online_rl_routes.py**: 4 new RL management API routes
  - POST /api/rl/act — manual RL decision test with context
  - POST /api/rl/update — manual Q update
  - POST /api/rl/status — full policy summary + double-Q divergence detection
  - POST /api/rl/reset — reset Q table for a user

### Technical
- StateEncoder: 4D→1D encoding, 144 contexts manageable for online learning
- Future: meta_learner can tune α/γ/ε_initial dynamically
- rl_action injected to handle_chat context for downstream use
  - Post-rollback: 12h cooldown per parameter, 10-entry rollback history limit
- **Canary deployment**: `start_canary_test(params)` — 5% user sampling → 24h observe → promote/rollback
  - Acute deterioration in canary group → immediate global rollback
  - Significant improvement → accelerated promotion before 24h
- **4 new API routes**: `/api/safeguards/rollback`, `/api/safeguards/status`, `/api/safeguards/canary-start`, `/api/safeguards/canary-evaluate`

### Integration
- **meta_learner.py**: `apply_adjustments()` calls `safeguards.check()` before applying — critical flags reject adjustments; post-apply recorded via `safeguards.record_adjustment()`; post-review cycle checks auto-rollback
- **pomdp_learner.py**: `_get_user()` calls `safeguards.check_param_safety()` before setting cluster-specific params
- **dp_router.py**: 4 safeguard management routes

### Testing
- Self-test in `dynamic_safeguards.py` (12 scenarios)
- All 14 pomdp_learner self-tests pass
- Verified: consecutive failure, acute deterioration, oscillation, rollback + cooldown, canary start/status

## v4.6.0 - Population Strategy Evolution

### New
- **population_manager.py**: `PopulationManager` class with cluster detection + strategy divergence engine
  - `cluster_users()` — k-means clustering based on user features (avg_score, volatility, bedtime, etc.)
  - `get_cluster_params(openid)` — returns the user's cluster-specific param config
  - `record_outcome(openid, intervention, outcome)` — records experiment for cluster evaluation
  - `suggest_strategy_split()` — detects when clusters diverge >15% in positive rate
  - Periodic maintenance (re-clustering + parameter divergence)
  - Data stored in `data/population_clusters/cluster_{n}.json`
- **Clustering**: 6-dim feature vector, elbow method for optimal k, min 3 users per cluster
- **Strategy divergence**: clusters with superior outcomes amplify their unique params; inferior clusters converge toward global
- **New user assignment**: allocated to nearest cluster based on feature vector
- **4 new API routes**: `/api/population/clusters`, `/api/population/maintenance`, `/api/population/strategy-split`, `/api/population/summary`

### Integration
- **pomdp_learner.py**: 
  - `POMDPEngine.population_manager` reference
  - `_get_user()` applies cluster-specific params (beta, forget_factor, alpha0, intervention_rate)
  - `observe()` calls `record_outcome` when effect is available
- **meta_learner.py**: 
  - New `population_aware_adjustment(openid)` method
  - Integrated into `daily_review()` — runs population maintenance alongside param tuning
- **dp_router.py**: 
  - `handle_sleep_analyze` records intervention outcome to population manager
  - 4 population management routes added

### Testing
- Self-test in `population_manager.py` (11 scenarios)
- All 14 pomdp_learner self-tests pass
- Verified: 2 populations auto-cluster, params diverge, split detection works at >15% threshold

## v4.5.3 - Temporal Depth Enhancement (Phase 3)

### New
- **working_memory.py** extensions:
  - `temporal_signature(openid)` — velocity (1st diff mean), acceleration (2nd diff mean), volatility (std), periodicity
  - `state_context(openid)` — "正在改善", "正在恶化", "触底反弹", "高位回落", "持平震荡"

### Integration
- **behavior_predictor.py**: `format_prediction_context` now includes temporal state/speed/acceleration context
- **conscious_decider.py**: 4 temporal state voting factors:
  - "正在恶化": push +20, delay_push +10
  - "触底反弹": in_chat +15, probe +5
  - "高位回落": delay_push +10, skip +5
  - "正在改善": in_chat +5
- **chat_prompt_builder.py**: `build_pomdp_context` appends `[时序: 状态=XXX, 速度=XX, 加速度=XX, 波动=XX]`

## v4.5.2 - Behavior Predictor (Phase 2)

### New
- **behavior_predictor.py**: `BehaviorPredictor` class
  - `predict_tonight(openid)` — linear regression + prev_score smoothing → predicted score ± CI
  - `predict_trend(openid)` — recent 3d vs prior 3d mean diff → direction (improving/declining/stable/erratic) + velocity + acceleration
  - `anomaly_score(openid)` — z-score based deviation from recent history
  - `detect_patterns(openid)` — weekly periodicity, Monday anxiety, weekend late detection
  - `get_prediction_error(openid, actual)` — persistent error tracking
  - `format_prediction_context(openid)` — formatted text for prompt injection

### Integration
- **pomdp_learner.py**: 
  - `POMDPEngine.behavior_predictor` auto-loaded
  - Each `observe()`/`observe_survey()` records prediction error
  - Persistent large error → auto-reduce forget_factor λ
- **chat_prompt_builder.py**: `build_pomdp_context` appends prediction info `[预测: ...]`
- **dp_router**: Prediction context flows through `build_pomdp_context` into system prompt

## v4.5.1 - Working Memory Module (Phase 1)

### New
- **working_memory.py**: `WorkingMemory` class with sliding window (N=10) per user
  - `push(openid, entry)` — add interaction to sliding window
  - `recent(openid, n=5)` — recent interactions list
  - `recent_trend(openid)` — 3-point score trend (up/down/flat + slope)
  - `short_term_belief(openid)` — weighted average of last 5 (newer = higher weight)
  - `recent_interventions(openid, n=3)` — last intervention types
  - `get_volatility(openid)` — standard deviation of recent scores
  - Per-user persistence to `data/working_memory/{openid}.json`

### Integration
- **pomdp_learner.py**: 
  - `POMDPEngine.working_memory` reference
  - `observe()` / `observe_survey()` auto-push to WM
  - `_push_to_wm()` helper method
  - `_get_short_term_context()` returns formatted text `[短期记忆: ...]`
- **chat_prompt_builder.py**: `build_pomdp_context` appends short-term memory section
- **conscious_decider.py**: 
  - WM signal collection in `_collect_signals`
  - New voting factor: trend=down + long>60 → push+15
  - New voting factor: trend=up + long<50 → chat+10
- **meta_learner.py**: `short_term_volatility` from WM's std
  - High volatility (>15) → increase β (explore more)
  - Low volatility (<5) → decrease β (exploit more)

### Testing
- Self-test in `working_memory.py` (6 scenarios)
- Integration test suite: `tests/test_wm_integration.py`

## [Previous versions...]
